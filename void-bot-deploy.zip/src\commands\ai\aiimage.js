const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const aiService = require('../../services/aiService');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('aiimage')
    .setDescription('Generate an image with AI (DALL-E)')
    .addStringOption(o => o.setName('prompt').setDescription('Describe the image you want').setRequired(true))
    .addStringOption(o => o.setName('size').setDescription('Image size').setRequired(false)
      .addChoices({ name: '256x256', value: '256x256' }, { name: '512x512', value: '512x512' }, { name: '1024x1024', value: '1024x1024' })),

  async execute(interaction) {
    const prompt = interaction.options.getString('prompt');
    const size = interaction.options.getString('size') || '512x512';

    await interaction.deferReply();

    if (!aiService.openai) {
      return interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xff4757).setDescription('AI features are not configured.')] });
    }

    try {
      const response = await aiService.openai.images.generate({
        model: 'dall-e-3',
        prompt,
        n: 1,
        size: size === '256x256' ? '1024x1024' : size, // DALL-E 3 minimum is 1024
      });

      const imageUrl = response.data[0]?.url;
      if (!imageUrl) throw new Error('No image URL returned');

      const embed = new EmbedBuilder()
        .setColor(0x6c5ce7)
        .setTitle('🎨 AI Generated Image')
        .setDescription(`**Prompt:** ${prompt}`)
        .setImage(imageUrl)
        .setFooter({ text: `Requested by ${interaction.user.tag}` })
        .setTimestamp();

      interaction.editReply({ embeds: [embed] });
    } catch (err) {
      console.error('[AI] /aiimage error:', err.message);
      interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xff4757).setDescription(`Failed to generate image: ${err.message.slice(0, 200)}`)] });
    }
  }
};
