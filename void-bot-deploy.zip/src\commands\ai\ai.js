const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const aiService = require('../../services/aiService');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ai')
    .setDescription('Ask the AI anything')
    .addStringOption(o => o.setName('question').setDescription('Your question').setRequired(true))
    .addStringOption(o => o.setName('personality').setDescription('AI personality').setRequired(false)
      .addChoices(
        { name: 'Friendly', value: 'friendly' },
        { name: 'Funny', value: 'funny' },
        { name: 'Gamer', value: 'gamer' },
        { name: 'Anime', value: 'anime' },
        { name: 'Professional', value: 'professional' },
      )),

  async execute(interaction) {
    const question = interaction.options.getString('question');
    const personality = interaction.options.getString('personality') || 'friendly';

    await interaction.deferReply();

    const systemPrompt = aiService.personalities[personality] || aiService.personalities.friendly;
    const messages = [
      { role: 'system', content: `${systemPrompt}\nUser: ${interaction.user.username}. Keep responses concise.` },
      { role: 'user', content: question },
    ];

    try {
      if (!aiService.openai) {
        return interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xff4757).setDescription('AI features are not configured. Please set your OPENAI_API_KEY.')] });
      }

      const completion = await aiService.openai.chat.completions.create({
        model: 'gpt-3.5-turbo',
        messages,
        max_tokens: 800,
        temperature: 0.8,
      });

      const reply = completion.choices[0]?.message?.content?.trim() || 'I couldn\'t generate a response.';

      const embed = new EmbedBuilder()
        .setColor(0x6c5ce7)
        .setTitle('🤖 AI Response')
        .setDescription(`**Q:** ${question}\n\n**A:** ${reply}`)
        .setFooter({ text: `${personality} personality • ${completion.usage?.total_tokens || 0} tokens` })
        .setTimestamp();

      interaction.editReply({ embeds: [embed] });
    } catch (err) {
      console.error('[AI] /ai error:', err.message);
      interaction.editReply({ embeds: [new EmbedBuilder().setColor(0xff4757).setDescription('An error occurred. Please try again later.')] });
    }
  }
};
